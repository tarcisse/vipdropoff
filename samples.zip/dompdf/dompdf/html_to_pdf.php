<?php
$filename = "dompdf/www/test_dompdf.html";

require("dompdf/dompdf_config.inc.php");
	
$dompdf = new DOMPDF();

$dompdf->load_html_file($filename);

// OU di vous avez accès au contenu HTML plutot qu'au fichier HTML lui-même
//$dompdf->load_html($html); 

// d'autres formats sont dispo, il est aussi possible de définir un format en "pt"
$dompdf->set_paper("a4", "landscape"); 

$dompdf->render();

// Si vous voulez le faire télécharger par le navigateur
$dompdf->stream("document.pdf", array("Attachment" => true));

// OU si vous voulez le mettre dans un ficher sur le serveur
// file_put_contents("document.pdf", $dompdf->output());

// Tout un tas d'options sont possibles, pour plus de détails : 
// http://code.google.com/p/dompdf/wiki/Usage#Using_the_dompdf_class_directly
?>	