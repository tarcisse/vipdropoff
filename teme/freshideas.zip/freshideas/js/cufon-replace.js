Cufon.replace('#menu a', { fontFamily: 'Copse', hover:true, color: '-linear-gradient(#fdfdfd, #dedede, #b4b4b4)' });
Cufon.replace('h2, .button, .list2 a, #sign_up a, h3', { fontFamily: 'Copse', hover:true });
Cufon.replace('h1', { fontFamily: 'Copse', hover:true });

